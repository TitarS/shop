<div class="view-title">Third party compatibility
	<div class="generic-buttons">
		<a class="generic-button save" ng-click="save()">save</a>
	</div>
</div>
<table class="form">
	<tr>
		<td>Support YMM if present:</td>
		<td>
			<sbuttons options="['yes','no']" model="general.ymm"></sbuttons>
		</td>
	</tr>
</table>